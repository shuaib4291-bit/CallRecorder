package com.example.callrec

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import java.io.File

class MainActivity : Activity() {
    private lateinit var list: ListView
    private lateinit var status: TextView
    private var files = listOf<File>()
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 24, 24, 24)
        }
        val perm = Button(this).apply {
            text = "Grant permissions"
            setOnClickListener { askPermissions() }
        }
        val battery = Button(this).apply {
            text = "App settings (battery / auto-start)"
            setOnClickListener {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:$packageName"))
                )
            }
        }
        status = TextView(this).apply { text = "Tap a recording to play. Long-press to delete." }
        list = ListView(this)
        root.addView(perm)
        root.addView(battery)
        root.addView(status)
        root.addView(list)
        setContentView(root)

        list.setOnItemClickListener { _, _, pos, _ -> play(files[pos]) }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            AlertDialog.Builder(this)
                .setMessage("Delete ${files[pos].name}?")
                .setPositiveButton("Delete") { _, _ -> files[pos].delete(); refresh() }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
        askPermissions()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun askPermissions() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_PHONE_STATE)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    private fun refresh() {
        val dir = getExternalFilesDir("recordings")
        files = dir?.listFiles()?.filter { it.extension == "m4a" }?.sortedByDescending { it.name } ?: listOf()
        list.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            files.map { "${it.nameWithoutExtension}  (${it.length() / 1024} KB)" })
    }

    private fun play(f: File) {
        player?.release()
        player = MediaPlayer().apply {
            setDataSource(f.absolutePath)
            prepare()
            start()
        }
    }

    override fun onDestroy() {
        player?.release()
        super.onDestroy()
    }
}
